# CODEDOJO_Final — Upgraded CodeDojo Daily Hub

## Palette & Architecture
- **Palette**: `#7C444F` (Plum Deep), `#9F5255` (Rose Berry), `#E16A54` (Coral Flame), `#F39E60` (Amber Glow)
- **Current Phase**: Separate `index.html`, `styles.css`, and `app.js` with Web Worker sandboxing, EventBus observer state, Team Access Codes, deduplicated scoring, streak heatmap, and Levenshtein similarity check.
- **Future Dynamic Phase**: `react-ts-scaffold/src/App.tsx` and `backend/server.js`.
- **Tests**: Run `node tests/run-tests.js`.
