import React, { useState } from "react";

export interface Problem {
  id: string;
  title: string;
  difficulty: "Easy" | "Medium" | "Hard";
  tags: string[];
  points: number;
}

export const PALETTE = {
  plumDeep: "#7C444F",
  roseBerry: "#9F5255",
  coralFlame: "#E16A54",
  amberGlow: "#F39E60",
} as const;

export const CodeDojoApp: React.FC<{ initialProblems: Problem[] }> = ({ initialProblems }) => {
  const [selectedId, setSelectedId] = useState<string>(initialProblems[0]?.id ?? "");
  const [difficulty, setDifficulty] = useState<string>("ALL");

  const visible = initialProblems.filter(
    (p) => difficulty === "ALL" || p.difficulty === difficulty
  );

  return (
    <div style={{ borderColor: PALETTE.plumDeep }} className="dojo-ts-shell">
      <header style={{ backgroundColor: PALETTE.plumDeep, color: "#fff", padding: "1rem" }}>
        <h1>CodeDojo Daily (React + TypeScript Phase)</h1>
      </header>
      <main style={{ padding: "1rem" }}>
        <select value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
          <option value="ALL">All</option>
          <option value="Easy">Easy</option>
          <option value="Medium">Medium</option>
          <option value="Hard">Hard</option>
        </select>
        <ul>
          {visible.map((p) => (
            <li key={p.id} onClick={() => setSelectedId(p.id)}>
              {p.title} ({p.points} pts) {selectedId === p.id ? "• Active" : ""}
            </li>
          ))}
        </ul>
      </main>
    </div>
  );
};
