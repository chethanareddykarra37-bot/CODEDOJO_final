const express = require("express");
const crypto = require("crypto");

const app = express();
app.use(express.json({ limit: "64kb" }));

// Minimal token/session helper for API endpoints (replace secret via env in production)
const sessions = new Map();

app.post("/api/auth/login", (req, res) => {
  const handle = String(req.body?.handle || "").trim();
  const pin = String(req.body?.pin || "");
  if (!/^[a-zA-Z0-9_-]{3,24}$/.test(handle) || pin.length < 4) {
    return res.status(400).json({ error: "Invalid handle or PIN" });
  }
  const token = crypto.randomBytes(24).toString("hex");
  sessions.set(token, { handle, createdAt: Date.now() });
  return res.json({ token, handle });
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "codedojo-api" });
});

module.exports = { app, sessions };
